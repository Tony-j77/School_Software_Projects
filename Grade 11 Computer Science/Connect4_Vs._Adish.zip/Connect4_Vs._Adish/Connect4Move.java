public class Connect4Move{
	public int value;
	public int move;
	
	public Connect4Move(int value, int move){
		this.value = value;
		this.move = move;
	}
}