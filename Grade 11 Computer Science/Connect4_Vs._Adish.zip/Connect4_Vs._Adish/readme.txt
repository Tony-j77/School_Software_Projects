Assign Connect4.jar file to buildpath (reference libraries for vscode)

Run game from Connect4.java file. 

Credits for Connect4.jar: Delos Chang